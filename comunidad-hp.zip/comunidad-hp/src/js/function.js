    var drawer = document.querySelector('app-drawer');
    document.querySelector('paper-icon-button').addEventListener('tap', function() {
      drawer.toggle();
    });
      
      document.querySelector('.cerrar').addEventListener('tap', function() {
      drawer.toggle();
    });